#ifndef TOKENIZE_HPP
#define TOKENIZE_HPP

#include <string>
#include <vector>


std::vector<std::string> tokenize(const std::string sentence);
#endif